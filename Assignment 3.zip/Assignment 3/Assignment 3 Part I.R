---
title: "Assignment 3 Part 1"
author: "Frank Longo"
date: "2023-10-25"
---
  
# Set working Directory
wd_path <- "/Users/frank/Desktop/Classes/QMB 6304 Data Visualization/Assignment 3"
setwd(wd_path)


library(dplyr)
library(plotrix)
library(sm)

# Question 1

CarsSold <- read.csv("CarSales.csv")


# Question 2
{
  avg_selling_price <- tapply(CarsSold$SalePrice, CarsSold$Make, mean)
  avg_purchase_price <- tapply(CarsSold$CostPrice, CarsSold$Make, mean)
  avg_labor_price <- tapply(CarsSold$LaborCost, CarsSold$Make, mean)
  avg_parts_price <- tapply(CarsSold$SpareParts, CarsSold$Make, mean)
  

  salesprice_range <- seq(0, ceiling(max(avg_selling_price) / 40000) * 40000, by = 40000)
  price_range <- seq(0, ceiling(max(avg_purchase_price) / 20000) * 20000, by = 20000)
  
  
  # 2x2 Matrix 
  par(mfrow = c(2, 2))
  
  # Scatter plot A
  plot(avg_selling_price, avg_purchase_price, pch = 19, col = "blue", xaxt='n',yaxt='n', xlab = "Average Sale Price", ylab = "Average Cost Price", xlim = c(min(avg_selling_price) * 0.9, max(avg_selling_price) * 1.1))
  abline(h=mean(CarsSold$CostPrice), v=mean(CarsSold$SalePrice), lwd=2, lty =2, col="tan") 
  text(avg_selling_price, avg_purchase_price, row.names(avg_selling_price), cex=0.8, pos=4, col="red")
  title(expression(italic("Average Sale Price vs Average Cost")), cex.main = 0.80)
  axis(1, at = salesprice_range, paste0(salesprice_range/1000,"K"))
  axis(2, at = price_range, paste0(price_range/1000,"K"),las=1)
  box(col = 'navy')
  
  
  # Scatter plot B
  plot(avg_selling_price, avg_labor_price, pch = 15, col = "blue", xaxt='n', xlab = "Average Sale Price", ylab = "Average Labor Cost", xlim = c(min(avg_selling_price) * 0.9, max(avg_selling_price) * 1.1),las =1)
  abline(h=mean(CarsSold$LaborCost), v=mean(CarsSold$SalePrice), lwd=2, lty =2, col="tan")
  text(avg_selling_price, avg_labor_price, row.names(avg_selling_price), cex=0.8, pos=4, col="red")
  title(expression(italic("Average Sales Price vs Average Labor Cost")),cex.main = 0.80)
  axis(1, at = salesprice_range, paste0(salesprice_range/1000,"K"))
  box(col = 'navy')
  
  # Scatter plot C
  plot(avg_selling_price, avg_parts_price, pch = 17, col = "blue", xaxt='n', xlab = "Average Sale Price", ylab = "Average Spare Parts Cost", xlim = c(min(avg_selling_price) * 0.9, max(avg_selling_price) * 1.1),las=1)
  abline(h=mean(CarsSold$SpareParts), v=mean(CarsSold$SalePrice), lwd=2, lty =2, col="tan")
  text(avg_selling_price, avg_parts_price, row.names(avg_selling_price), cex=0.8, pos=4, col="red")
  title(expression(italic("Average Sales Price vs Average Parts Cost")),cex.main = 0.80)
  axis(1, at = salesprice_range, paste0(salesprice_range/1000,"K"))
  box(col = 'navy')
  
  # Scatter plot D
  plot(avg_labor_price, avg_parts_price, pch = 21, col = "red", bg = "blue", xlab = "Average Labor Cost", ylab = "Average Spare Parts Cost",  ylim = c(min(avg_parts_price) * 0.9, max(avg_parts_price) * 1.1),las=1)
  abline(lm(avg_labor_price ~ avg_parts_price), col = "red", lwd = 2)
  abline(h=mean(CarsSold$SpareParts), v=mean(CarsSold$LaborCost), lwd=2, lty =2, col="tan")
  text(avg_labor_price, avg_parts_price, row.names(avg_labor_price), cex=0.8, pos=3, col="red")
  title(expression(italic("Average Labor Cost vs Average Parts Cost")),cex.main = 0.80)
  box(col = 'navy')
  

  par(mfrow = c(1, 1))
}


# Question 3
{
  salesprice_barplot <- seq(0, ceiling(max(avg_selling_price) / 40000) * 40000, by = 10000)
  graph_labels <- ifelse(salesprice_barplot == 0, "0", paste0(salesprice_barplot / 1000, "K"))
  barplot(avg_selling_price, xaxt='n', horiz=TRUE, las =1, cex.names = 0.6, col=c("slategray2","royalblue1","cyan3","plum2","lemonchiffon2","coral1","darkseagreen2")) 
  axis(1, at = salesprice_barplot, labels = graph_labels, cex.axis=0.8)
  title("Average Vehicle Sales Price by Make (Ten Thousands)",cex.main = 0.60,xlab = "Average Sale Price", ylab = "Car Make")
}


# Question 4
{
  Cars_purchased <- table(CarsSold$VehicleType, CarsSold$CountryName)
  barplot(Cars_purchased, beside = TRUE, col = rainbow(nrow(Cars_purchased)), xlab = "Car Type", ylab = "CarsSold Sold", main = "Number of Cars Sold by Country and Vehicle Type",las=1, cex.names = .8)
  legend("topleft", legend = rownames(Cars_purchased), fill = rainbow(nrow(Cars_purchased)), title = "Vehicle Type")
}



# Question 5
{
  sales_totals <- tapply(CarsSold$SalePrice, CarsSold$VehicleType, sum)
  slice_colors <- c("honeydew2","firebrick", "deepskyblue")
  pie(sales_totals, labels = paste(names(sales_totals), round(100 * sales_totals / sum(sales_totals), 1), "%"), col = slice_colors, main = "Total Sales by Car Type")
}



# Question 6
{
  library(plotrix)
  
  avg_selling_price <- tapply(CarsSold$SalePrice, CarsSold$CountryName, mean)
  avg_selling_price <- avg_selling_price[order(avg_selling_price, decreasing = TRUE)]
  fan_slice_palette <- c("orange","green","navy","purple","steelblue1","brown")
  fan.plot(avg_selling_price, max.span = 1.2,labels = names(avg_selling_price),col = fan_slice_palette)
  title("Average Sale Price by Country")
}


# Question 7
{
  hist_pricing_range <- seq(0, ceiling(max(CarsSold$CostPrice) / 20000) * 40000, by = 40000)
  bin_count <- 10
  hist(CarsSold$CostPrice, breaks = bin_count, freq = TRUE,xaxt='n', col = "cyan", main = "Histogram of Cost Frequency", xlab = 'Cost of Car', ylab ='',
                    ylim = c(0, max(hist(CarsSold$CostPrice, breaks = bin_count, plot = FALSE)$counts) + 1),las=1)
  axis(1, at = hist_pricing_range, paste0(hist_pricing_range/1000,"K"))
  rug(jitter(CarsSold$CostPrice, amount = 0), side = 1, col = "green4")
  box(col = 'black')
}


# Question 8

{
  CarsSold$Profit <- CarsSold$SalePrice - CarsSold$CostPrice
  profit_instances <- seq(-80000, ceiling(max(CarsSold$Profit) / 40000) * 40000, by = 40000)
  profity_weight <- density(CarsSold$Profit)
  plot(profity_weight, main = "Profit Density Curve",xaxt='n' ,xlab = "", ylab = "", type = "n",las=1)
  polygon(profity_weight, col = "plum3")
  axis(1, at = profit_instances, paste0(profit_instances/1000,"K"))
  rug(jitter(CarsSold$CostPrice, amount = 0), side = 1, col = "green4")
}


# Question 9
{
  library(sm)
  
  sm.density.compare(CarsSold$Profit, xlab = "Profit Density by Car Type", ylab = "",group = CarsSold$VehicleType, col = rainbow(length(unique(CarsSold$VehicleType))),lty = 1, lwd = 2)
  legend("topright", legend = unique(CarsSold$VehicleType), col = c("blue","red","green"), lty = 1 ,lwd = 2, title = "Car Type")
  title(main = "Vehicle Type by Density")
}

# Question 10
{
  salesprice_range_box <- seq(0, ceiling(max(CarsSold$SalePrice)) * 40000, by = 40000)
  boxplot(CarsSold$SalePrice ~ CarsSold$VehicleType, col = rainbow(length(unique(CarsSold$VehicleType))), xlab = "", yaxt='n' ,ylab = "Sale Price", main = "Sale Prices by Car Type")
  legend("topleft", legend = unique(CarsSold$VehicleType), fill = c("blue", "green", "red"), title = "Car Type")
  axis(2, at = salesprice_range_box, paste0(salesprice_range_box/1000,"K"),las=1)
}
